
UZBEK MESSENGER 4.0

Features:
- Persistent login (no logout after refresh)
- Online users list
- Chat history
- Modern UI

Run:
npm install
npm start

Open:
http://localhost:5000
