
const socket = io();
let currentUser = null;

const authModal = document.getElementById("authModal");

// Persistent login
window.onload = () => {
  const savedUser = localStorage.getItem("uzbekUser");
  if (savedUser) {
    currentUser = JSON.parse(savedUser);
    authModal.style.display = "none";
    socket.emit("register", currentUser);
  }
};

function register() {
  const nickname = document.getElementById("nickname").value;
  if (!nickname) return;

  currentUser = { nickname };
  localStorage.setItem("uzbekUser", JSON.stringify(currentUser));

  authModal.style.display = "none";
  socket.emit("register", currentUser);
}

function sendMessage() {
  const input = document.getElementById("messageInput");
  if (!input.value) return;

  socket.emit("message", input.value);
  input.value = "";
}

socket.on("message", (msg) => {
  const div = document.createElement("div");
  div.innerHTML = "<b>" + msg.sender + "</b>: " + msg.text +
                  "<br><small>" + msg.time + "</small>";
  document.getElementById("messages").appendChild(div);
});

socket.on("users", (users) => {
  const list = document.getElementById("users");
  list.innerHTML = "";
  users.forEach(u => {
    const li = document.createElement("li");
    li.textContent = u.nickname;
    list.appendChild(li);
  });
});

socket.on("chatHistory", (history) => {
  history.forEach(msg => {
    const div = document.createElement("div");
    div.innerHTML = "<b>" + msg.sender + "</b>: " + msg.text +
                    "<br><small>" + msg.time + "</small>";
    document.getElementById("messages").appendChild(div);
  });
});
